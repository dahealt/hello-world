package fr.free.nrw.commons.mwapi.model;

public class Query {
    public Page[] pages;

    public Query() {
        pages = new Page[0];
    }

}
