package fr.free.nrw.commons.logging;

/**
 * Can be implemented to set the log level for file tree
 */
public interface LogLevelSettableTree {
    void setLogLevel(int logLevel);
}
