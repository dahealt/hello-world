package fr.free.nrw.commons.media;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class MediaDetailSpacer extends View {
    public MediaDetailSpacer(Context context) {
        super(context);
    }

    public MediaDetailSpacer(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MediaDetailSpacer(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
}
