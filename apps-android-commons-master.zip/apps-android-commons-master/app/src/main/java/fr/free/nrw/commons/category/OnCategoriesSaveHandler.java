package fr.free.nrw.commons.category;

import java.util.List;

public interface OnCategoriesSaveHandler {
    void onCategoriesSave(List<String> categories);
}
