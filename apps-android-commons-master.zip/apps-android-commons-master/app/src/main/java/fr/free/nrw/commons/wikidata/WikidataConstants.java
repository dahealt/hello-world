package fr.free.nrw.commons.wikidata;

public class WikidataConstants {
    public static final String WIKIDATA_ENTITY_ID_PREF = "WikiDataEntityId";
}
